package student.StudentCrud.domain;
import student.StudentCrud.domain.Student;
public class StudentDomain {

}
