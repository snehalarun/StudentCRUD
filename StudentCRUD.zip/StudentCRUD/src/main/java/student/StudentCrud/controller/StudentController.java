package student.StudentCrud.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import student.StudentCrud.service.StudentService;
import student.StudentCrud.domain.Student;

@Controller
public class StudentController {
	
	@Autowired
	private StudentService ser;
	
	@GetMapping("/")
	public String viewHomePage(Model model) {
		List<Student> lstd=ser.listAll();
		model.addAttribute("liststudent",lstd);
		System.err.println("Get/");			
		return "index";
	}
	
	@GetMapping("/")
	public String add(Model model) {
		model.addAttribute("student",new Student());
		return "new";
		
	}
	
	@RequestMapping(value="/save",method=RequestMethod.POST)
	public String saveStudent(@ModelAttribute("student")Student std) {
		ser.save(std);
		return "redirect";
	}
	
	@RequestMapping("/edit/{id}")
	public ModelAndView showEditStudentPage(@PathVariable(name="id") int id) {
		ModelAndView mav=new ModelAndView("new");
		Student std=ser.get(id);
		return mav;
	}
	
	@RequestMapping("/delete/{id}")
	public String deleteStudent(@PathVariable(name="id") int id) {
		ser.delete(id);
		return "redirect";
	}
	

}
