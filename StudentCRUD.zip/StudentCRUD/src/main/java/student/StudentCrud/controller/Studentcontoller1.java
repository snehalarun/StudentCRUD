package student.StudentCrud.controller;

import java.util.ArrayList;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class Studentcontoller1 {
	
	@GetMapping("studentlist")
	ModelAndView fetchData() {
		ModelAndView mv=new ModelAndView();
		ArrayList<String> al=new ArrayList<>();
		al.add("snehal");
		al.add("Arun");
		mv.setViewName("showallStudent");
		mv.addObject("data", al);
		return mv;
	}

}
