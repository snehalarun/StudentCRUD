package student.StudentCrud.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import student.StudentCrud.domain.Student;
import student.StudentCrud.repository.StudentRepository;

@Service
public class StudentService {
	
	@Autowired
	private StudentRepository repo;
	
	
	public void save(Student std) {
		repo.save(std);
	}
	public Student get(int id) {
		return repo.findById(id).get();
	}
	public void delete(int id) {
		repo.deleteById(id);
	}
	public List<Student> listAll() {
		// TODO Auto-generated method stub
		return repo.findAll();
	}
}
